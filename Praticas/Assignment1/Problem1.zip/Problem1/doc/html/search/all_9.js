var searchData=
[
  ['scount_0',['sCount',['../structsCount.html',1,'']]],
  ['sfilehandler_1',['sFileHandler',['../structsFileHandler.html',1,'']]],
  ['sharedmemory_2ec_2',['sharedMemory.c',['../sharedMemory_8c.html',1,'']]],
  ['sharedmemory_2eh_3',['sharedMemory.h',['../sharedMemory_8h.html',1,'']]],
  ['sm_5fclose_4',['sm_close',['../sharedMemory_8c.html#acdba6eb2310386605ffaa530cd051dde',1,'sm_close():&#160;sharedMemory.c'],['../sharedMemory_8h.html#acdba6eb2310386605ffaa530cd051dde',1,'sm_close():&#160;sharedMemory.c']]],
  ['sm_5fgetchunkofdata_5',['sm_getChunkOfData',['../sharedMemory_8c.html#a9d9277eb29321a610be9bb461969fb2a',1,'sm_getChunkOfData(int id, unsigned char data[DATA_BUFFER_SIZE], unsigned int *size, FileHandler *fileHandler):&#160;sharedMemory.c'],['../sharedMemory_8h.html#a9d9277eb29321a610be9bb461969fb2a',1,'sm_getChunkOfData(int id, unsigned char data[DATA_BUFFER_SIZE], unsigned int *size, FileHandler *fileHandler):&#160;sharedMemory.c']]],
  ['sm_5fgetresults_6',['sm_getResults',['../sharedMemory_8c.html#a6db9192ad4993c3c2225f4a7f7fd6d8c',1,'sm_getResults(Results *results):&#160;sharedMemory.c'],['../sharedMemory_8h.html#a6db9192ad4993c3c2225f4a7f7fd6d8c',1,'sm_getResults(Results *results):&#160;sharedMemory.c']]],
  ['sm_5finitialize_7',['sm_initialize',['../sharedMemory_8c.html#a103b9141e423a416c3cefaf7dc55bccd',1,'sm_initialize(int nFiles, char files[nFiles][MAX_FILE_NAME_SIZE]):&#160;sharedMemory.c'],['../sharedMemory_8h.html#a103b9141e423a416c3cefaf7dc55bccd',1,'sm_initialize(int nFiles, char files[nFiles][MAX_FILE_NAME_SIZE]):&#160;sharedMemory.c']]],
  ['sm_5fregisterresult_8',['sm_registerResult',['../sharedMemory_8c.html#a989f3f908ac0b478b552d5a7056eabce',1,'sm_registerResult(int id, FileHandler fileHandler, Count *count):&#160;sharedMemory.c'],['../sharedMemory_8h.html#a989f3f908ac0b478b552d5a7056eabce',1,'sm_registerResult(int id, FileHandler fileHandler, Count *count):&#160;sharedMemory.c']]],
  ['sresults_9',['sResults',['../structsResults.html',1,'']]],
  ['statusworkers_10',['statusWorkers',['../countWords_8c.html#aacc2e6de862cc619b0a65b8b8e8931bf',1,'statusWorkers():&#160;countWords.c'],['../sharedMemory_8c.html#aacc2e6de862cc619b0a65b8b8e8931bf',1,'statusWorkers():&#160;sharedMemory.c']]],
  ['success_11',['SUCCESS',['../sharedMemory_8h.html#aa90cac659d18e8ef6294c7ae337f6b58',1,'sharedMemory.h']]]
];
