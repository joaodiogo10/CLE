var searchData=
[
  ['words_0',['words',['../structsCount.html#a3593b0ef9e603cebc0e8e790064ac569',1,'sCount']]],
  ['wordsbeginninginvowel_1',['wordsBeginningInVowel',['../structsCount.html#aa139b86f51149425adf29a56018cb9c6',1,'sCount']]],
  ['wordsendinginconsoant_2',['wordsEndingInConsoant',['../structsCount.html#ad16376055db3b46e79d2aea15fba5505',1,'sCount']]]
];
