var searchData=
[
  ['ptrfile_0',['ptrFile',['../structsFileHandler.html#ae92c0973a9e1f7dcf822971d78b2c70d',1,'sFileHandler']]]
];
