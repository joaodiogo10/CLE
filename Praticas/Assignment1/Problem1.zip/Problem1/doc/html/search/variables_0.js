var searchData=
[
  ['count_0',['count',['../structsFileHandler.html#a544c56c6685e8fab904a59a7d1f71c55',1,'sFileHandler::count()'],['../structsResults.html#ad5fcfcbf9caa8a3d54e6ebc3710a735e',1,'sResults::count()']]]
];
