var searchData=
[
  ['filename_0',['fileName',['../structsFileHandler.html#ae63f3529a7c36cf1edd0ed40fe7ebd93',1,'sFileHandler::fileName()'],['../structsResults.html#a2f431baa17d65609a36cdd0fda8b372b',1,'sResults::fileName()']]]
];
