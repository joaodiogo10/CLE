var searchData=
[
  ['ascii_5ffirst_5flower_5fcase_5fletter_0',['ASCII_FIRST_LOWER_CASE_LETTER',['../utf8_8c.html#a8cda90f0ec8e17427170dd6359dd8ac8',1,'utf8.c']]],
  ['ascii_5ffirst_5fupper_5fcase_5fletter_1',['ASCII_FIRST_UPPER_CASE_LETTER',['../utf8_8c.html#af74916bbcb85674fac800633bf2b7fd7',1,'utf8.c']]],
  ['ascii_5flast_5flower_5fcase_5fletter_2',['ASCII_LAST_LOWER_CASE_LETTER',['../utf8_8c.html#a3a4b40f3f9667061888adff0e7044113',1,'utf8.c']]],
  ['ascii_5flast_5fupper_5fcase_5fletter_3',['ASCII_LAST_UPPER_CASE_LETTER',['../utf8_8c.html#a523317c255e5ac9257b7051fce37d82b',1,'utf8.c']]]
];
