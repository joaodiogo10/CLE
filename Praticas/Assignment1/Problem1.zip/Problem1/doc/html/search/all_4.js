var searchData=
[
  ['getutf8charsize_0',['getUTF8CharSize',['../utf8_8c.html#aa7aea4870ac31427fedc29ec6c98e3d1',1,'getUTF8CharSize(unsigned char firstByte):&#160;utf8.c'],['../utf8_8h.html#aa7aea4870ac31427fedc29ec6c98e3d1',1,'getUTF8CharSize(unsigned char firstByte):&#160;utf8.c']]],
  ['getutf8chartype_1',['getUTF8CharType',['../utf8_8c.html#a4bf9a33f1f7bfbdb3bdeade66d20a177',1,'getUTF8CharType(unsigned int utf8Char):&#160;utf8.c'],['../utf8_8h.html#a4bf9a33f1f7bfbdb3bdeade66d20a177',1,'getUTF8CharType(unsigned int utf8Char):&#160;utf8.c']]]
];
