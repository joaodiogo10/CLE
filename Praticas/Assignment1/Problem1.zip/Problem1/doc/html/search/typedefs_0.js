var searchData=
[
  ['filehandler_0',['FileHandler',['../sharedMemory_8h.html#ad4ae10927963f41e761481f4044ff509',1,'sharedMemory.h']]]
];
