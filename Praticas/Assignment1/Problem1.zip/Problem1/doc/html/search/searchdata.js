var indexSectionsWithContent =
{
  0: "acdfgmnprsuw",
  1: "s",
  2: "cpsu",
  3: "gmprs",
  4: "cfpsw",
  5: "f",
  6: "c",
  7: "adfmns"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Macros"
};

