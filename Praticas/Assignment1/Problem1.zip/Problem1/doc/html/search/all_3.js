var searchData=
[
  ['failure_0',['FAILURE',['../sharedMemory_8h.html#a6d58f9ac447476b4e084d7ca383f5183',1,'sharedMemory.h']]],
  ['filehandler_1',['FileHandler',['../sharedMemory_8h.html#ad4ae10927963f41e761481f4044ff509',1,'sharedMemory.h']]],
  ['filename_2',['fileName',['../structsFileHandler.html#ae63f3529a7c36cf1edd0ed40fe7ebd93',1,'sFileHandler::fileName()'],['../structsResults.html#a2f431baa17d65609a36cdd0fda8b372b',1,'sResults::fileName()']]]
];
