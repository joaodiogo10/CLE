var searchData=
[
  ['utf8_2ec_0',['utf8.c',['../utf8_8c.html',1,'']]],
  ['utf8_2eh_1',['utf8.h',['../utf8_8h.html',1,'']]]
];
