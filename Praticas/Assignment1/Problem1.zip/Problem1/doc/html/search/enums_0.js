var searchData=
[
  ['charactertype_0',['CharacterType',['../utf8_8h.html#ad0cd52c7c9b13be13f9aafebd2e1c860',1,'utf8.h']]]
];
