var searchData=
[
  ['data_5fbuffer_5fsize_0',['DATA_BUFFER_SIZE',['../probConst_8h.html#ab723c5f0e9759c70ed582dfd77431ff7',1,'probConst.h']]]
];
