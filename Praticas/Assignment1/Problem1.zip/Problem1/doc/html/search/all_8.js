var searchData=
[
  ['readutf8char_0',['readUTF8Char',['../utf8_8c.html#a94224cdc20386a7622f80a4ab332da9e',1,'readUTF8Char(FILE *ptrFile, unsigned int *utf8Char):&#160;utf8.c'],['../utf8_8h.html#a94224cdc20386a7622f80a4ab332da9e',1,'readUTF8Char(FILE *ptrFile, unsigned int *utf8Char):&#160;utf8.c']]]
];
