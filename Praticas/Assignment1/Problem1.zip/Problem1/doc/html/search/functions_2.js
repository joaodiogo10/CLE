var searchData=
[
  ['printresults_0',['printResults',['../countWords_8c.html#a2ca71add7979d1362d421d40909b32b8',1,'countWords.c']]]
];
