var searchData=
[
  ['statusworkers_0',['statusWorkers',['../countWords_8c.html#aacc2e6de862cc619b0a65b8b8e8931bf',1,'statusWorkers():&#160;countWords.c'],['../sharedMemory_8c.html#aacc2e6de862cc619b0a65b8b8e8931bf',1,'statusWorkers():&#160;sharedMemory.c']]]
];
