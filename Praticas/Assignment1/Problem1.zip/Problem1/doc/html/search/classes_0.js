var searchData=
[
  ['scount_0',['sCount',['../structsCount.html',1,'']]],
  ['sfilehandler_1',['sFileHandler',['../structsFileHandler.html',1,'']]],
  ['sresults_2',['sResults',['../structsResults.html',1,'']]]
];
